document.addEventListener("deviceready", function() {
    IntegrityCheck.checkSignature(
        function(){ console.log("Security Passed"); },
        function(){ alert("App Tampered!"); navigator.app.exitApp(); }
    );
}, false);
