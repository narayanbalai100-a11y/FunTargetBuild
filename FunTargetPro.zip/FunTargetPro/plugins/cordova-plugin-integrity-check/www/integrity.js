var exec = require('cordova/exec');

module.exports = {
    checkSignature: function(success, error) {
        exec(success, error, "SignatureVerifier", "checkSignature", []);
    }
};
