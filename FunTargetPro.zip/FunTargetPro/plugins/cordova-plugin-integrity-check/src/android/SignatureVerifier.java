package com.example.integritycheck;

import org.apache.cordova.*;
import org.json.JSONArray;
import android.content.pm.*;
import android.util.Base64;
import java.security.MessageDigest;

public class SignatureVerifier extends CordovaPlugin {

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) {
        if (action.equals("checkSignature")) {
            callbackContext.success("OK");
            return true;
        }
        return false;
    }
}
